/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UI;

import Bussiness.Control;
import Data.Jugador;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 *
 * @author donwe
 */
public class InputControl implements KeyListener{
    private Control control; 
    private Escenario escenario;
    
    public InputControl(Control control, Escenario escenario) {
        this.control = control;
        this.escenario=escenario;
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
       switch(e.getKeyCode()){
            case KeyEvent.VK_W:
                escenario.getGame().getJugador().setUp(true);
                break;
            case KeyEvent.VK_A:
                escenario.getGame().getJugador().setLeft(true);
                break;
            case KeyEvent.VK_S:
                escenario.getGame().getJugador().setDown(true);
                break;
            case KeyEvent.VK_D:
                escenario.getGame().getJugador().setRight(true);
                break;
            default:
                break;
        }    
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch(e.getKeyCode()){
            case KeyEvent.VK_W:
                escenario.getGame().getJugador().setUp(false);
                break;
            case KeyEvent.VK_A:
                escenario.getGame().getJugador().setLeft(false);
                break;
            case KeyEvent.VK_S:
                escenario.getGame().getJugador().setDown(false);
                break;
            case KeyEvent.VK_D:
                escenario.getGame().getJugador().setRight(false);
                break;
            default:
                break;
        }    
    }
}
