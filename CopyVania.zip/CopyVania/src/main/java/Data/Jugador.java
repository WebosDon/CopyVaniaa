/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

import java.util.ArrayList;

public class Jugador extends Entidad {
    Objeto[] inventario=new Objeto[10];
    Habilidad[] habilidades=new Habilidad[5];

    public Jugador() {
        super(100, 10, 5,new ArrayList<Integer>(),new int[][]{{25,25},{25,15}},new String[]{"Hola"});
        super.setColliders(new int[]{1,2,3,4,5});
    }
    
}
