/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bussiness;

import Data.Jugador;
import UI.InputControl;

/**
 *
 * @author csant
 */
public class Control implements Movimiento{
    private Jugador jugador;

    public Control( Jugador jugador) {
        this.jugador = jugador;
    }
    
    public void notificar(int letra){
        switch (letra) {
            case 1:
                jugador.setAceleración(new int[]{0,2});
                break;
            case 2:
                jugador.setAceleración(new int[]{-2,0});
                
                break;
            case 3:
                
                break;
            case 4:
                jugador.setAceleración(new int[]{2,0});
                break;
            default:
                throw new AssertionError();
        }
    }
}
