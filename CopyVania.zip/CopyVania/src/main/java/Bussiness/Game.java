/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bussiness;

import Data.Entidad;
import Data.Jugador;
import Data.MapaActual;
import UI.Escenario;
import UI.Ventana;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.Timer;

/**
 *
 * @author donwe
 */
public class Game implements ActionListener{
    private Ventana gameWindow;
    private Jugador jugador=new Jugador();
    private Control control=new Control(jugador);
    private Escenario gamePanel;
    private Timer timer;
    private MapaActual mapa=new MapaActual(new int[][]{{1},{1}});
    
    public Game(){
        Entidad entidad=new Entidad(100, 4, 5, new ArrayList<Integer>(),new int[][]{{50,25}},new String[]{""});
        entidad.setColliders(new int[]{1,2,3});
        entidad.setPosiciónFutura(new int[]{100, 0});
        entidad.setPosición();
        mapa.setObjetos(new Entidad[]{jugador,entidad});
        gamePanel = new Escenario(control,mapa);
        gameWindow = new Ventana(gamePanel);
        gamePanel.setFocusable(true); 
        gamePanel.requestFocus();
        timer=new Timer(50, this);
        timer.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        jugador.setAceleración();
        ColliderManager.Colisión(mapa);
        jugador.setPosición();
        gamePanel.repaint();
    }
}
